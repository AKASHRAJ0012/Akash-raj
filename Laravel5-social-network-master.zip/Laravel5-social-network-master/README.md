# Laravel5-social-network
This app was named "Laravel PHP - Create a Social Network (Full App)". This is a tutorial that I followed and accomplished on youtube.com that was lectured by Mindspace.
